import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class Loader {

    public static void main(String[] args) {

        final DateTimeFormatter DateForm = DateTimeFormatter.ofPattern("yyyy.MM.dd");
        final DateTimeFormatter DateFormPlus = DateTimeFormatter.ofPattern("yyyy.MM.dd, E");

        Scanner sc = new Scanner(System.in);
        System.out.println("Введите дату рождения в формате гггг.мм.дд");
        String birthDateString = sc.nextLine();
        LocalDate birthDate = LocalDate.parse(birthDateString, DateForm);
        int calcYear;
        System.out.println("Дата рождения - " + birthDate.format(DateFormPlus));
        int currentYear = LocalDate.now().getYear();
        int n = 0;
        do {
            LocalDate dateN = birthDate.plusYears(n);
            calcYear = dateN.getYear();
            System.out.println(n + " - " + dateN.format(DateFormPlus));
            n++;
        } while (currentYear > calcYear);
    }
}
