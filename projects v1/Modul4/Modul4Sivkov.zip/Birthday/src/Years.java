//import java.time.LocalDate;
//import java.time.Month;
//
//public class Years {
//
//    LocalDate firstDate;
//    LocalDate seconfDate;
//
//
//    public String getOperator() {
//        return "+";
//    }
//
//    LocalDate today = LocalDate.now();
//    LocalDate myBirthDay = LocalDate.of(1988, Month.APRIL, 3);
//
//
//    public void getResult(LocalDate firstDate, LocalDate secondDate) {
//        LocalDate result = firstDate.plusYears(secondDate.getYear());
//        System.out.println(result);
//        System.out.println(today);
//        System.out.println(myBirthDay);
//    }
//}
