import org.javagram.TelegramApiBridge;
import org.javagram.response.AuthCheckedPhone;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Loader {
    public static void main(String[] args) throws IOException
    {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        TelegramApiBridge bridge = new TelegramApiBridge("149.154.167.50:443", 627636, "750aede6af39af5e831683fc121fbfb7");

        System.out.println("Please, type phone number:");
        AuthCheckedPhone chekedPhone = bridge.authCheckPhone(reader.readLine().trim());
        System.out.println(chekedPhone.isRegistered());
    }
}
