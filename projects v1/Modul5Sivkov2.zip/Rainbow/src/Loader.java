import java.util.Arrays;
import java.util.Collections;

public class Loader {

    public static void main(String[] args) {

        String [] rainbow = {"Red", "Orange", "Yellow", "Green", "Cyan", "Blue", "Violet"};

        System.out.println("Прямая последовательность:");
        for (int i = 0; i < rainbow.length; i++) {
            System.out.println(rainbow[i]);
        }

        System.out.println("Разворот:");
        Collections.reverse(Arrays.asList(rainbow));
        for (String item : rainbow) {
            System.out.println(item);
        }
    }
}
