import java.util.*;

public class Loader {

    public static void main(String[] args) {

        /* К блатным номерам отнесем номера, которые:
        1. включают в себя три одинаковых цифры номера
        2. включают в себя три одинаковых буквы серии
        3. имеют одинаковые цифры номера и региона
        4. имеют номер 000-009
         */
        /* На всякий случай напишу идею формирования названий для переменных
        Для номера а123вс01:
        а - переменная pp1
        123 - переменная pp2
        в - переменная pp3
        c - переменная pp4
        01 -  переменная pp5
        * */

        ArrayList<String> baseGibdd = new ArrayList<>();
        String baseCharr = "укенхваросмт";

        for (int pp5 = 1; pp5 < 5; pp5++) {
            int numberOfRegion = pp5;
            for (int pp2 = 1; pp2 < 1000; pp2++) {
                int numberOfZnak = pp2;
                for (int pp1 = 0; pp1 < baseCharr.length(); pp1++) {
                    String firstLetter = baseCharr.substring(pp1, pp1 + 1);
                    for (int pp3 = 0; pp3 < baseCharr.length(); pp3++) {
                        String secondLetter = baseCharr.substring(pp3, pp3 + 1);
                        for (int pp4 = 0; pp4 < baseCharr.length(); pp4++) {
                            String thirdLetter = baseCharr.substring(pp4, pp4 + 1);
// Проверяем соответствие номера условиям 1, 3, 4.
                            if (numberOfZnak < 10 || numberOfZnak % 100 == 0 || numberOfZnak % 111 == 0 || numberOfZnak == numberOfRegion) {
                                String formattedNumberOfZnak = String.format("%03d", numberOfZnak);
                                String formattedNumberOfRegion = String.format("%03d", numberOfRegion);
                                String step1 = firstLetter.concat(formattedNumberOfZnak);
                                String step2 = step1.concat(secondLetter);
                                String step3 = step2.concat(thirdLetter);
                                String step4 = step3.concat(formattedNumberOfRegion);

                                baseGibdd.add(step4);
                                System.out.println(step4);
                            }
//Проверяем соответствие номера условию 2.
                            else if (firstLetter.equals(secondLetter)) {
                                if (firstLetter.equals(thirdLetter)) {
                                    String formattedNumberOfZnak = String.format("%03d", numberOfZnak);
                                    String formattedNumberOfRegion = String.format("%03d", numberOfRegion);

                                    String step1 = firstLetter.concat(formattedNumberOfZnak);
                                    String step2 = step1.concat(secondLetter);
                                    String step3 = step2.concat(thirdLetter);
                                    String step4 = step3.concat(formattedNumberOfRegion);

                                    baseGibdd.add(step4);
                                    System.out.println(step4);

                                }
                            }
                        }
                    }
                }
            }
        }

        Collections.sort(baseGibdd); //сортировка для бинарного поиска
        Set hashBaseGibdd = new HashSet<String>(baseGibdd); //синхронизация для HashSet
        SortedSet treeBaseGibdd = Collections.synchronizedSortedSet(new TreeSet<String>(baseGibdd)); //синхронизация для TreeSet

        Scanner sc = new Scanner(System.in);

        for (; ; ) {
            System.out.println("Введите номер: ");
            String inputNumber = sc.nextLine();
// бинарный поиск
            long time1 = System.currentTimeMillis();
            int pos = Collections.binarySearch(baseGibdd, inputNumber);
            if (pos < 0) {
                System.out.printf("Номера %s в базе нет ", inputNumber);
            } else System.out.printf("Номер %s в базе присутствует ", inputNumber);
            long time2 = System.currentTimeMillis();
            Long time3 = time2 - time1;
            System.out.println(time3 + " мс");
// перебор
            long time4 = System.currentTimeMillis();
            if (baseGibdd.contains(inputNumber)) {
                System.out.printf("Номер %s в базе присутствует ", inputNumber);
            } else System.out.printf("Номера %s в базе нет ", inputNumber);
            long time5 = System.currentTimeMillis();
            Long time6 = time5 - time4;
            System.out.println(time6 + " мс");
//HashSet
            long time7 = System.currentTimeMillis();
            if (hashBaseGibdd.contains(inputNumber)) {
                System.out.printf("Номер %s в базе присутствует ", inputNumber);
            } else System.out.printf("Номера %s в базе нет ", inputNumber);
            long time8 = System.currentTimeMillis();
            Long time9 = time8 - time7;
            System.out.println(time9 + " мс");
//TreeSet
            long time10 = System.currentTimeMillis();
            if (treeBaseGibdd.contains(inputNumber)) {
                System.out.printf("Номер %s в базе присутствует ", inputNumber);
            } else System.out.printf("Номера %s в базе нет ", inputNumber);
            long time11 = System.currentTimeMillis();
            Long time12 = time11 - time10;
            System.out.println(time12 + " мс");

        }
    }
}