public class Loader {

    public static void main(String[] args) {

        Integer startYear = 1997;
        Integer currentYear = 2019;
        Integer quantityYears = currentYear - startYear + 1;
        Integer quantityRegions = 89;

        Integer[][] numberOfPassport = new Integer[quantityRegions][quantityYears];
        Integer numericRegionNumber;
        Integer numericYearNumber;
        for (numericRegionNumber = 1; numericRegionNumber < quantityRegions + 1; numericRegionNumber++) {
            for (numericYearNumber = startYear; numericYearNumber < currentYear + 1; numericYearNumber++) {
                String numberRegion = numericRegionNumber.toString(numericRegionNumber);
                String numberYear = numericYearNumber.toString().substring(2);
                String yearAndNumber = numberRegion.concat(numberYear);
                Integer passportSeries = Integer.valueOf(yearAndNumber);
                System.out.printf("%04d\t", passportSeries);

            }
            System.out.println();
        }
    }
}
