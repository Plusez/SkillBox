import java.time.DateTimeException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.Scanner;


public class Loader {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Введите дату рождения в формате гггг.мм.дд");
        String birthDateString = sc.nextLine();
        LocalDate birthDate = LocalDate.parse(birthDateString, DateTimeFormatter.ofPattern("yyyy.MM.dd"));
        int calcYear;
        System.out.println("Дата рождения - " + birthDate.format(DateTimeFormatter.ofPattern("yyyy.MM.dd, E")));
        int currentYear = LocalDate.now().getYear();
        int n = 0;
        do {
            LocalDate dateN = birthDate.plusYears(n);
            calcYear = dateN.getYear();
            System.out.println(n + " - " + dateN.format(DateTimeFormatter.ofPattern("yyyy.MM.dd, E")));
            n++;
        } while (currentYear > calcYear);
    }
}
