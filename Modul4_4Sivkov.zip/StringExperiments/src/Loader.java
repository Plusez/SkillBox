import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Loader {
    public static void main(String[] args) {

        //Символы и их коды

        for (int a = 0; a < 2513; a++) {
            char b = (char) a;
            String groupAbc = "йцукенгшщзхъфывапролджэячсмитьбюЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮ";
            int groupIndex = groupAbc.indexOf(b);
            if (groupIndex == -1) {
                continue;
            } else {
                System.out.println("символ - " + a + " - " + b);
            }
        }

        for (int a = 0; a < 2513; a++) {
            char b = (char) a;
            String groupAbc = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM";
            int groupIndex = groupAbc.indexOf(b);
            if (groupIndex == -1) {
                continue;
            } else {
                System.out.println("символ - " + a + " - " + b);
            }
        }

         //Расчет общего заработка трех человек

        String text = "Вася заработал 5000 рублей, Петя - 7563 рубля, а Маша - 30000 рублей";
        int sum = 0;
        int lengthOfText = text.length();
        for (int i = 0; i < lengthOfText; i++) {
            String subStr1 = text.substring(i);
            if (subStr1.charAt(0) == ' ') {
                String subStr2 = subStr1.substring(1);
                if (Character.toString(subStr2.charAt(0)).matches("[0-9]")) {
                    int space = subStr2.indexOf(' ');
                    String subStr3 = subStr2.substring(0, space);
                    int z = Integer.parseInt(subStr3);
                    sum += z;
                }
            }
        }
        System.out.println(sum);

// Это вариант из предыдущего курса. Насколько я понимаю, он лучше.
        Pattern myReg = Pattern.compile("[0-9]+");
        Matcher matcher = myReg.matcher(text);
        int sumX = 0;
        while (matcher.find()) {
            Integer x = Integer.parseInt(text.substring(matcher.start(), matcher.end()));
            sumX += x;
        }
        System.out.println(sumX);

        //Эксперименты с ФИО

        Scanner sc = new Scanner(System.in);
        System.out.println("Введите Фамилию Имя Отчество");
        String input = sc.nextLine();
        String fullName = input.trim();
        int space1 = fullName.indexOf(' '); //выделяем фамилию
        String surName = fullName.substring(0, space1);
        System.out.println("Фамилия - " + surName);
        String subStr1 = fullName.substring(space1).trim();
        int space2 = subStr1.indexOf(' '); //выделяем имя
        String name = subStr1.substring(0, space2);
        System.out.println("Имя - " + name);
        String subStr2 = subStr1.substring(space2).trim();
        System.out.println("Отчество - " + subStr2);
    }
}

