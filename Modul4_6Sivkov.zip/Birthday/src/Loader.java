import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.Scanner;


public class Loader {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Введите дату рождения: dd");
        int dd = sc.nextInt();
        System.out.println("Введите месяц рождения: mm");
        int MM = sc.nextInt();
        System.out.println("Введите год рождения: yyyy");
        int yyyy = sc.nextInt();
        int calcYear;
        LocalDate birthDate = LocalDate.of(yyyy, MM, dd);
        System.out.println("Дата рождения - " + birthDate);
        LocalDate currentDate = LocalDate.now();
        int currentYear = currentDate.getYear();
        int n = 0;
        Locale localeRu = new Locale("ru", "RU");
        do {
            LocalDate dateN = birthDate.plusYears(n);
            calcYear = dateN.getYear();
            DayOfWeek dayOfWeek = dateN.getDayOfWeek();
            System.out.print(n + " - ");
            System.out.print(dateN + " - ");
            System.out.println(dayOfWeek.getDisplayName(TextStyle.FULL, localeRu));
            n = n + 1;
        } while (currentYear > calcYear);
    }
}
