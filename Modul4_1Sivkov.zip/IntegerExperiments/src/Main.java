import java.util.Scanner;

public class Main {
    public static int sum;

    public static void main(String[] args) {
        Container container = new Container();
        container.count += 7843;
        System.out.println(container.count);
        System.out.println("sumDigits - " + sumDigits());
    }

    public static Integer sumDigits() {
        //@TODO: write code here
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите число : ");
        Integer number = scanner.nextInt();
        int i = number.toString().length();
        int q = 0;
        for (int y = 0; y < i; y++) {
            char ch = number.toString().charAt(y);
            int a = Character.getNumericValue(ch);
            q = q + a;
            sum = q;
        }
        return sum;
    }
}
